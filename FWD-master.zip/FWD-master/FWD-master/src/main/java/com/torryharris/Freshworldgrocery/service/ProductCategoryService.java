package com.torryharris.Freshworldgrocery.service;

import com.torryharris.Freshworldgrocery.repository.ProductRepository;
import com.torryharris.Freshworldgrocery.model.Products;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductCategoryService implements ProductCategoryInterface{
    @Autowired
      private ProductRepository productRepository;

      
    @Override
    public List<Products> getProductsbyFruits() {
        return productRepository.findByproductCategory("fruits");
    }

    @Override
    public List<Products> getProductsbyVegetables() {
        return productRepository.findByproductCategory("vegetables");
    }

    @Override
    public List<Products> getProductsbySpices() {
        return productRepository.findByproductCategory("spices");
    }
}
