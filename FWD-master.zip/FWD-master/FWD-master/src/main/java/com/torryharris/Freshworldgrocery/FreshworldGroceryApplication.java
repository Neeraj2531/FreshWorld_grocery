package com.torryharris.Freshworldgrocery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Collections;

@SpringBootApplication
@EnableSwagger2
	public class FreshworldGroceryApplication {
	private static final Logger LOG = LoggerFactory.getLogger(FreshworldGroceryApplication.class);
		public static void main(String[] args) {
			LOG.info("Start");
			SpringApplication.run(FreshworldGroceryApplication.class, args);
			LOG.info("End");
		}
		@Bean
		public Docket swaggerConfiguration(){
			return new Docket(DocumentationType.SWAGGER_2)
					.select()
					.paths(PathSelectors.ant("/api/*"))
					.apis(RequestHandlerSelectors.basePackage("com.torryharris.Freshworldgrocery"))
					.build()
					.apiInfo(apiDetails());

		}
		private ApiInfo apiDetails(){
			return new ApiInfo(
					"FreshWorld grocery API",
					"Sample API for FreshWorld Application",
					"1.0",
					"Free To Use",
					new springfox.documentation.service.Contact("Neeraj Kumar","http://freshworld.com","abc@gmail.com"),
					"API License",
					"http://freshworld.com",
					Collections.emptyList()

			);
		}

	}
