package com.torryharris.Freshworldgrocery.service;

import com.torryharris.Freshworldgrocery.repository.ProductRepository;
import com.torryharris.Freshworldgrocery.model.Products;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
@Service
public class ProductService implements ProductServiceInterface{
    @Autowired
    private ProductRepository repo;

    public List<Products> listAll(){

        return (List<Products>) repo.findAll();
    }

    public void saveProductToDB(MultipartFile file, String productName,String productCategory, Double price){
        Products p= new Products();
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if(fileName.contains("..")){
            System.out.println("not a valid file");
        }

        try {
            p.setImage(Base64.getEncoder().encodeToString(file.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        p.setProductName(productName);
        p.setProductCategory(productCategory);
        p.setPrice(price);
        repo.save(p);
    }



    //Method used to update product inside database
    @Override
    public void updateProductToDB(MultipartFile file, int product_id, String productName,String productCategory, Double price) {
        Products p= new Products();
        String fileName= StringUtils.cleanPath(file.getOriginalFilename());
        if(fileName.contains(".."))
        {
            System.out.println("not a valid file");
        }
        try {
            p.setImage(Base64.getEncoder().encodeToString(file.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        p.setProduct_id(product_id);
        p.setProductName(productName);
        p.setProductCategory(productCategory);
        p.setPrice(price);
        repo.save(p);

    }


    public void save(Products products) {

        repo.save(products);
    }

    public Products get(Integer id){
        Optional<Products> result=repo.findById(id);
        Products products=null;
        if(result.isPresent()){
            products=result.get();
        }
        else{
            throw new RuntimeException("Products not found for id " + id);
        }
        return products;
    }

    public void delete(Integer id) throws UserPrincipalNotFoundException {

        repo.deleteById(id);
    }
}