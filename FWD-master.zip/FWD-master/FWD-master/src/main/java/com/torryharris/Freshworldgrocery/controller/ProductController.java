package com.torryharris.Freshworldgrocery.controller;

import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.List;

import com.torryharris.Freshworldgrocery.model.Products;
import com.torryharris.Freshworldgrocery.service.ProductService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/api")
public class ProductController {
@Autowired
    private ProductService service;

    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    @RequestMapping("/index")
    public String index() {
        return "index";
    }

    @RequestMapping("/login")
    public String log() {
        return "login";
    }

    @RequestMapping("/signUp")
    public String signup() {
        return "signup1";
    }

    @RequestMapping("/adminlogin")
    public String adminlogin() {
        return "adminlogin";
    }

    @RequestMapping("/adminDash")
    public String admin() {
        return "adminDash";
    }

    @RequestMapping("/category")
    public String category() {
        return "category";
    }


    @GetMapping("/products")
    @ApiOperation(value = "Select Products",
            notes="Select Products Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Products selected successfully"),
            @ApiResponse(code=404, message="Invalid data"),
            @ApiResponse(code=500, message="Internal server error")})
    public String showProductList(Model model){
        List<Products> listProduct=service.listAll();
        model.addAttribute("listProducts", listProduct);
        return "products";
    }
   @GetMapping("/fruitscategory")
    public String showProductListByFruits(Model model){
        List<Products> listProduct=service.listAll();
        model.addAttribute("listProducts", listProduct);
        return "redirect:/byFruits";
    }
    @GetMapping("/spicescategory")
    public String showProductListBySpices(Model model){
        List<Products> listProduct=service.listAll();
        model.addAttribute("listProducts", listProduct);
        return "redirect:/bySpices";
    }
    @GetMapping("/vegetablescategory")
    public String showProductListByVegetables(Model model){
        List<Products> listProduct=service.listAll();
        model.addAttribute("listProducts", listProduct);
        return "redirect:/byVegetables";
    }

/*

    @GetMapping ("/new")
    public String addProperty(Model model){

        Products prod=new Products();
        model.addAttribute("product", prod);
        //model.addAttribute("pageTitle", "Add New Property");
        return "addProduct";
    }

    @PostMapping("/save")
    public String saveProduct(@RequestParam("file") MultipartFile file,
                              @RequestParam("productName") String name,
                              @RequestParam("productCategory") String category,
                              @RequestParam("price") Double price)
            {
        service.saveProductToDB(file,name,category,price);

        return "redirect:/products";}
*/

    @GetMapping ("/newfruits")
    public String addProperty(Model model){

        Products prod=new Products();
        model.addAttribute("product", prod);
        //model.addAttribute("pageTitle", "Add New Property");
        return "addFruits";
    }

    @PostMapping("/savefruits")
    @ApiOperation(value = "Update products",
            notes="Select Products Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Products updated successfully"),
            @ApiResponse(code=404, message="Invalid data"),
            @ApiResponse(code=500, message="Internal server error")})
    public String saveProduct(@RequestParam("file") MultipartFile file,
                              @RequestParam("productName") String name,
                              @RequestParam("productCategory") String category,
                              @RequestParam("price") Double price)
    {
        service.saveProductToDB(file,name,category,price);

        return "redirect:/fruitscategory";
    }

    @GetMapping ("/newvegetables")
    public String addProperty1(Model model){

        Products prod=new Products();
        model.addAttribute("product", prod);
        //model.addAttribute("pageTitle", "Add New Property");
        return "addVegetables";
    }

    @PostMapping("/savevegetables")
    public String saveProduct1(@RequestParam("file") MultipartFile file,
                              @RequestParam("productName") String name,
                              @RequestParam("productCategory") String category,
                              @RequestParam("price") Double price)
    {
        service.saveProductToDB(file,name,category,price);

        return "redirect:/vegetablescategory";
    }


    @GetMapping ("/newspices")
    public String addProperty2(Model model){

        Products prod=new Products();
        model.addAttribute("product", prod);
        //model.addAttribute("pageTitle", "Add New Property");
        return "addSpices";
    }

    @PostMapping("/savespices")
    public String saveProduct2(@RequestParam("file") MultipartFile file,
                              @RequestParam("productName") String name,
                              @RequestParam("productCategory") String category,
                              @RequestParam("price") Double price)
    {
        service.saveProductToDB(file,name,category,price);

        return "redirect:/spicescategory";
    }



    @PostMapping("/saveUpdatedProducts")
    public String saveUpdatedProperty(@RequestParam("file") MultipartFile file,
                                      @RequestParam("product_id") int id,
                                      @RequestParam("productName") String name,
                                      @RequestParam("productCategory") String category,
                                      @RequestParam("price") Double price)
    {
        service.updateProductToDB(file,id,name,category,price);

        return "redirect:/products";
    }



    @GetMapping("/products/edit/{id}")
    public String editProducts(@PathVariable("id") Integer id, Model model){
        Products prod=service.get(id);
        model.addAttribute("product", prod);
        model.addAttribute("pageTitle", "Edit Product (ID: "+id+")");
        return "updateProduct";
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") Integer id, RedirectAttributes ra){
        try{
            service.delete(id);
            ra.addFlashAttribute("message", "The Product ID "+id+" has been deleted.");
        }
        catch (UserPrincipalNotFoundException e){
            ra.addFlashAttribute("message", e.getMessage());
        }
        return "redirect:/products";
    }

    @RequestMapping("home")
    public String home() {
        return "home";
    }

    @RequestMapping("shop")
    public String shop() {
        return "shop";
    }

    @RequestMapping("contact")
    public String contact() {
        return "contact";
    }

    @RequestMapping("vegetables")
    public String vegetables() {
        return "vegetables";
    }

    @RequestMapping("fruits")
    public String fruits() {
        return "fruits";
    }

    @RequestMapping("fgs")
    public String fgs() {
        return "fgs";
    }

    @RequestMapping("payment")
    public String payment() {
        return "payment";
    }

    @RequestMapping("thank")
    public String thank() {
        return "thank";
    }

}