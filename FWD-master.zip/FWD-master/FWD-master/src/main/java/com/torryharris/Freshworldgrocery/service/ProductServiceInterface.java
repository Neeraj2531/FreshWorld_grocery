package com.torryharris.Freshworldgrocery.service;

import org.springframework.web.multipart.MultipartFile;

public interface ProductServiceInterface {
    public void updateProductToDB(MultipartFile file,int product_id, String productName, String productCategory, Double price);


}
