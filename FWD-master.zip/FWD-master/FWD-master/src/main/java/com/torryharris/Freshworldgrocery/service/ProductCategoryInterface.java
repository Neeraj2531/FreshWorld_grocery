package com.torryharris.Freshworldgrocery.service;

import com.torryharris.Freshworldgrocery.model.Products;

import java.util.List;

public interface ProductCategoryInterface {

    public List<Products> getProductsbyFruits();
    public List<Products> getProductsbyVegetables();
    public List<Products> getProductsbySpices();
}
