package com.torryharris.Freshworldgrocery.controller;


import com.torryharris.Freshworldgrocery.model.Products;
import com.torryharris.Freshworldgrocery.service.ProductCategoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/api")

public class ProductCategoryController {

    @Autowired
    private ProductCategoryService service;

    @GetMapping("/byFruits")
    @ApiOperation(value = "Order Fruits",
    notes="Select Fruits Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Fruits selected successfully"),
    @ApiResponse(code=404, message="Invalid data"),
    @ApiResponse(code=500, message="Internal server error")})
    public String showProductListByFruits(Model model) {
        List<Products> listProduct=service.getProductsbyFruits();
        model.addAttribute("listProducts", listProduct);
        return "fruitscategory";
    }
    @GetMapping("/byVegetables")
    @ApiOperation(value = "Order Vegetables",
            notes="Select Products Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Vegetables selected successfully"),
            @ApiResponse(code=404, message="Invalid data"),
            @ApiResponse(code=500, message="Internal server error")})
    public String showProductListByVegetables(Model model) {
        List<Products> listProduct=service.getProductsbyVegetables();
        model.addAttribute("listProducts", listProduct);
        return "vegetablescategory";
    }

    @GetMapping("/bySpices")
    @ApiOperation(value = "Order Spices",
            notes="Select Products Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Spices selected successfully"),
            @ApiResponse(code=404, message="Invalid data"),
            @ApiResponse(code=500, message="Internal server error")})
    public String showProductListBySpices(Model model) {
        List<Products> listProduct=service.getProductsbySpices();
        model.addAttribute("listProducts", listProduct);
        return "spicescategory";
    }
    @GetMapping("/byfruits")
    @ApiOperation(value = "Order Fruits",
            notes="Select Fruits Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Fruits selected successfully"),
            @ApiResponse(code=404, message="Invalid data"),
            @ApiResponse(code=500, message="Internal server error")})
    public String showProductListByfruits(Model model) {
        List<Products> listProduct=service.getProductsbyFruits();
        model.addAttribute("listProducts", listProduct);
        return "fruits";
    }
    @GetMapping("/byvegetables")
    @ApiOperation(value = "Order vegetables",
            notes="Select Products Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Vegetables selected successfully"),
            @ApiResponse(code=404, message="Invalid data"),
            @ApiResponse(code=500, message="Internal server error")})
    public String showProductListByvegetables(Model model) {
        List<Products> listProduct=service.getProductsbyVegetables();
        model.addAttribute("listProducts", listProduct);
        return "vegetables";
    }

    @GetMapping("/byspices")
    @ApiOperation(value = "Order Spices",
            notes="Select Products Category")
    @ApiResponses(value={@ApiResponse(code=200,message="Spices selected successfully"),
            @ApiResponse(code=404, message="Invalid data"),
            @ApiResponse(code=500, message="Internal server error")})
    public String showProductListByspices(Model model) {
        List<Products> listProduct=service.getProductsbySpices();
        model.addAttribute("listProducts", listProduct);
        return "fgs";
    }
}
